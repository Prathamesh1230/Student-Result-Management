def calculate_total(s1, s2, s3):
    return s1 + s2 + s3

def calculate_percentage(s1, s2, s3):
    return round((s1 + s2 + s3) / 3, 2)
